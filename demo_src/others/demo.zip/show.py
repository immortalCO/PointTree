import json
import h5py
import os
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.gridspec as gridspec
import numpy as np


def plot_into_ax(ax, points, part=None, title='title'):
    points = points
    x, y, z = points[:,0], points[:,1], points[:,2]
    x -= x.mean()
    y -= y.mean()
    z -= z.mean()

    part = part
    color = part - part.min()
    colormap = np.array(['blue', 'red', 'green', 'cyan', 'purple', 'orange'])

    labx, laby, labz = 'x', 'y', 'z'
    lmin = min(x.min(), y.min(), z.min())
    lmax = max(x.max(), y.max(), z.max())

    ax.scatter(x, y, z, c=colormap[color], marker='.')

    ax.set_xlim(lmin, lmax)
    ax.set_ylim(lmin, lmax)
    ax.set_zlim(lmin, lmax)

    ax.set_xlabel(labx)
    ax.set_ylabel(laby)
    ax.set_zlabel(labz) 

    if title is not None:
        ax.set_title(title)


def plot(ckpt):
    fig = plt.figure(dpi=80)
    gs = gridspec.GridSpec(nrows=2, ncols=2, left=0, right=0.95, wspace=0.05, hspace=0.35, bottom=0.1, top=0.9)

    ax = fig.add_subplot(gs[0, 0], projection='3d')
    plot_into_ax(ax, ckpt['orig'], part=ckpt['ans'], title='(a) Original / Ground Truth')

    ax = fig.add_subplot(gs[0, 1], projection='3d')
    plot_into_ax(ax, ckpt['trans'], part=ckpt['ans'],  title='(b) Transformed / Ground Truth')

    ax = fig.add_subplot(gs[1, 0], projection='3d')
    plot_into_ax(ax, ckpt['pa'], part=ckpt['ans'], title='(c) Pre-aligned / Ground Truth')

    ax = fig.add_subplot(gs[1, 1], projection='3d')
    plot_into_ax(ax, ckpt['pa'], part=ckpt['out'], title='(d) Pre-aligned / PointTree Output')

    plt.show()



import sys
if len(sys.argv) != 2 or sys.argv[1] not in ["car", "chair", "guitar", "lamp", "motorbike", "pistol", "table"]:
    print("Invalid arguments: " + " ".join(sys.argv[1:]))
    print("Usage: python show.py <name: car|chair|guitar|lamp|motorbike|pistol|table>")
    exit()
a = "demo_files/" + sys.argv[1] + ".npy"
a = np.load(a, allow_pickle=True)
a = dict(a.flatten()[0])
plot(a)